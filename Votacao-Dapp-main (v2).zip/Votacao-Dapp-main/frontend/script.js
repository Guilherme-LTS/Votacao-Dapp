function votar() {
  const eleitor_id = document.getElementById('eleitor_id').value;
  const candidato = document.getElementById('candidato').value;

  if (!eleitor_id || !candidato) {
      document.getElementById('mensagem').textContent = "Preencha todos os campos.";
      return;
  }

  fetch('/votar', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
      },
      body: JSON.stringify({
          eleitor_id: eleitor_id,
          candidato: candidato
      })
  })
  .then(response => {
      if (!response.ok) {
          return response.json().then(data => { throw new Error(data.mensagem); });
      }
      return response.json();
  })
  .then(data => {
      document.getElementById('mensagem').textContent = data.mensagem;
  })
  .catch(error => {
      document.getElementById('mensagem').textContent = error.message;
      console.error('Erro ao votar:', error);
  });
}

function minerar() {
  fetch('/minerar')
  .then(response => response.json())
  .then(data => {
      document.getElementById('mensagem').textContent = data.mensagem;
  })
  .catch(error => {
      document.getElementById('mensagem').textContent = "Erro ao minerar.";
      console.error('Erro ao minerar:', error);
  });
}

function verResultados() {
  fetch('/resultados')
  .then(response => response.json())
  .then(data => {
      let resultadosHTML = '';
      for (const candidato in data.resultados) {
          resultadosHTML += `<p>${candidato}: ${data.resultados[candidato]} votos</p>`;
      }
      document.getElementById('resultados').innerHTML = resultadosHTML;
  })
  .catch(error => {
      document.getElementById('resultados').textContent = "Erro ao obter resultados.";
      console.error('Erro ao obter resultados:', error);
  });
}
