const urlBase = window.location.origin;

function votar() {
  const eleitor_id = document.getElementById('eleitor_id').value;
  const candidato = document.getElementById('candidato').value;

  fetch(`${urlBase}/votar`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ eleitor_id, candidato })
  })
  .then(res => res.json())
  .then(dados => {
    document.getElementById('mensagem').innerText = dados.mensagem;
  });
}

function minerar() {
  fetch(`${urlBase}/minerar`)
    .then(res => res.json())
    .then(dados => {
      document.getElementById('mensagem').innerText = dados.mensagem;
    });
}

function verResultados() {
  fetch(`${urlBase}/resultados`)
    .then(res => res.json())
    .then(data => {
      const resultados = data.resultados;
      let html = "<h2>Resultados:</h2>";
      for (let [candidato, votos] of Object.entries(resultados)) {
        html += `<p>${candidato}: ${votos} votos</p>`;
      }
      document.getElementById('resultados').innerHTML = html;
    });
}

function sincronizar() {
    fetch('/nodes/resolve')
      .then(response => response.json())
      .then(data => {
        document.getElementById('mensagem').innerText = data.mensagem;
      });
  }
